#include "testbench.h"


void Testbench::operation()
{
    // Tabla de salida
//    cout<<" | PIPE1 | PIPE2 | PIPE3 | PIPE4 |\n";
//    cout<<" | I | O | I | O | I | O | I | O |\n";

//    cout<<" | "<< fetch1.read()<<" | "<< pipe1_1.read();
//    cout<<" | "<< decode[0].read() << " | "<< pipe2[0].read();
//    cout<<" | "<< execute[0].read() << " | "<< pipe3[0].read();
//    cout<<" | "<< memory[0].read() << " | "<< pipe4[0].read() << " |\n";


//    cout<<" | "<< fetch2.read()<<" | "<< pipe1_2.read();
//    cout<<" | "<< decode[1].read() << " | "<< pipe2[1].read();
//    cout<<" | "<< execute[1].read() << " | "<< pipe3[1].read();
//    cout<<" | "<< memory[1].read() << " | "<< pipe4[1].read() << " |\n";


//    cout<<" | "<< fetch3.read()<<" | "<< pipe1_3.read();
//    cout<<" | "<< decode[2].read() << " | "<< pipe2[2].read();
//    cout<<" | "<< execute[2].read() << " | "<< pipe3[2].read();
//    cout<<" | "<< memory[2].read() << " | "<< pipe4[2].read() << " |\n";


//    cout<<" | "<< fetch4.read()<<" | "<< pipe1_4.read();
//    cout<<" | "<< decode[3].read() << " | "<< pipe2[3].read();
//    cout<<" | "<< execute[3].read() << " | "<< pipe3[3].read();
//    cout<<" | "<< memory[3].read() << " | "<< pipe4[3].read() << " |\n";

}
