#include "timer.h"

Timer::Timer()
{
    timer = new QTimer();
    timer->setSingleShot(true);
}

void Timer::setTime(int time)
{

}

void Timer::Start()
{

}
